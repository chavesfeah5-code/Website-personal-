GROUP PORTFOLIO WEBSITE
1. Extract this ZIP file.
2. Open index.html in a browser to preview the website.
3. To publish free with GitHub Pages:
   - Create a GitHub repository.
   - Upload index.html to the main/root folder.
   - Open Settings > Pages.
   - Select Deploy from a branch, choose main and /(root), then Save.
   - Wait for GitHub Pages to provide your website link.

CUSTOMIZE:
- Replace the letter initials in each profile circle with member photos if desired.
- Add social media links and public contact details only with each member's permission.
- Check spellings, school names, and details with all four members before publishing.
- Edit index.html using a text editor or VS Code.
